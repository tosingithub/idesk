This idioms corpus has 20174 samples, 1197 cases.
It has: Metaphor (72.7) Euphemism (11.82) Personification (2.22) Parallelism (0.32) Simile (6.11) Oxymoron (0.24) Paradox (0.56) Hyperbole (0.24) Literal (5.65) Irony (0.16)

Please, cite the paper mentioned at- github.com/tosingithub/idesk if you use this data.
